/**
 * CONFIGURAÇÃO DOS LINKS DE CHECKOUT
 * Insira aqui os links da sua plataforma de pagamento (ex: Kiwify, Hotmart, Eduzz, etc.)
 */

export const CHECKOUT_URLS = {
  // Link do Plano Completo (R$ 27,90)
  planoCompleto: '',

  // Link do Plano Básico (R$ 9,90)
  planoBasico: '',

  // Link da Oferta Especial do Pop-up (R$ 17,90)
  ofertaEspecial: '',
};

/**
 * Retorna a URL de checkout preservando parâmetros de rastreamento (UTMs)
 */
export const getCheckoutUrlWithParams = (baseUrl: string): string => {
  if (!baseUrl || baseUrl.trim() === '' || baseUrl === '#') {
    return '#';
  }
  if (typeof window === 'undefined' || !window.location.search) {
    return baseUrl;
  }
  const search = window.location.search.replace(/^\?/, '');
  if (!search) return baseUrl;
  const separator = baseUrl.includes('?') ? '&' : '?';
  return `${baseUrl}${separator}${search}`;
};

/**
 * Função utilitária para redirecionar diretamente ao checkout
 */
export const goToCheckout = (url: string) => {
  if (!url || url.trim() === '' || url === '#') return;
  const finalUrl = getCheckoutUrlWithParams(url);
  try {
    // Redirecionamento direto da janela atual
    window.location.href = finalUrl;
  } catch {
    window.open(finalUrl, '_blank');
  }
};
